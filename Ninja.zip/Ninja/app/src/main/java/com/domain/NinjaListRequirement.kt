package com.domain

import com.data.NinjaRepository
import com.data.network.model.NinjaObject


class NinjaListRequirement {

    private val repository = NinjaRepository()

    suspend operator fun invoke(
        limit:Int
    ): NinjaObject? = repository.getNinjaList(limit)
}