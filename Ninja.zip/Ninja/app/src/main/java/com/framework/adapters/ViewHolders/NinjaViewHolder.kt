package com.framework.adapters.ViewHolders

import android.content.Context
import android.content.Intent
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.data.network.model.NinjaBase
import com.domain.NinjaRequirement
import com.example.kotlin.ninja.databinding.ItemNinjaBinding
import com.framework.views.activities.NinjaDetailActivity
import com.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import  com.data.network.model.ninja.Ninja

class NinjaViewHolder(private val binding: ItemNinjaBinding) : RecyclerView.ViewHolder(binding.root) {

    fun bind(item: NinjaBase, context: Context){
        binding.TVName.text = item.name
        getNinjaInfo(item.url, binding.IVPhoto, context)

        binding.llNinja.setOnClickListener {
            passViewGoToNinjaDetail(item.url, context)
        }
    }

    private fun getNinjaInfo(url: String, imageView: ImageView, context: Context){
        var ninjaStringNumber: String = url.replace("https://api.api-ninjas.com/v1/dnslookup?domain", "")
        ninjaStringNumber = ninjaStringNumber.replace("/", "")
        val ninjaNumber: Int = Integer.parseInt(ninjaStringNumber)

        CoroutineScope(Dispatchers.IO).launch {
            val ninjaInfoRequirement = NinjaRequirement()
            val result: Ninja? = ninjaInfoRequirement(ninjaNumber)
            CoroutineScope(Dispatchers.Main).launch {

                val requestOptions = RequestOptions()
                    .centerCrop()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .fitCenter()
                    .priority(Priority.HIGH)

            }
        }
    }
    private fun passViewGoToNinjaDetail(url: String, context: Context){
        var intent: Intent = Intent(context, NinjaDetailActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        context.startActivity(intent)
        intent.putExtra(Constants.URL_NINJA, url)
    }
}
