package com.framework.viewmodel


import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.data.network.model.NinjaObject
import com.domain.NinjaListRequirement
import com.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NinjaViewModel:ViewModel() {

    val ninjaObjectLiveData = MutableLiveData<NinjaObject>()
    private val ninjaListRequirement = NinjaListRequirement()

    fun getNinjaList(){
        viewModelScope.launch(Dispatchers.IO) {
            val result: NinjaObject? = ninjaListRequirement(Constants.MAX_NINJA)
            Log.d("Salida", result?.count.toString())
            CoroutineScope(Dispatchers.Main).launch {
                ninjaObjectLiveData.postValue(result!!)
            }
        }
    }
}