package com.framework.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.data.network.model.NinjaBase
import com.example.kotlin.ninja.R
import com.example.kotlin.ninja.databinding.FragmentNinjaBinding
import com.framework.adapters.NinjaAdapter
import com.framework.viewmodel.NinjaViewModel


class NinjaFragment: Fragment() {
    private var _binding: FragmentNinjaBinding? = null

    private val binding get() = _binding!!

    private lateinit var viewModel: NinjaViewModel

    private lateinit var recyclerView: RecyclerView
    private val adapter : NinjaAdapter = NinjaAdapter()
    private lateinit var data:ArrayList<NinjaBase>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this)[NinjaViewModel::class.java]

        _binding = FragmentNinjaBinding.inflate(inflater, container, false)
        val root: View = binding.root

        data = ArrayList()

        initializeComponents(root)
        initializeObservers()
        viewModel.getNinjaList()

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun initializeComponents(root: View){
        recyclerView = root.findViewById(R.id.RVNinja)
    }

    private fun initializeObservers() {
        viewModel.ninjaObjectLiveData.observe(viewLifecycleOwner) { ninjaObject ->
            setUpRecyclerView(ninjaObject.results)
        }
    }

    private fun setUpRecyclerView(dataForList: ArrayList<NinjaBase>){
        recyclerView.setHasFixedSize(true)
        val gridLayoutManager = GridLayoutManager(
            requireContext(),
            2,
            GridLayoutManager.VERTICAL,
            false
        )
        recyclerView.layoutManager = gridLayoutManager
        adapter.NinjaAdapter (dataForList, requireContext())
        recyclerView.adapter = adapter
    }
}
