package com.data

import com.data.network.NinjaApiClient
import com.data.network.model.NinjaObject
import com.data.network.model.ninja.Ninja


class NinjaRepository() {
    private val apiNinja = NinjaApiClient()

    suspend fun getNinjaList(limit:Int): NinjaObject? = apiNinja.getNinjaList(limit)

    suspend fun getNinjaInfo(numberNinja:Int): Ninja?  = apiNinja.getNinjaInfo(numberNinja)


}