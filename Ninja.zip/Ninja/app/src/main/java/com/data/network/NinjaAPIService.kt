package com.data.network


import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Headers


interface NinjaAPIService {

    //https://api.api-ninjas.com/v1/dnslookup?domain=google.com
    @GET("dnslookup")
    suspend fun getNinjaList(
        @Query("limit") limit:Int
    ): com.data.network.model.NinjaObject

    @GET("ninja/{numberNinja}")
    suspend fun getNinjaInfo(
        @Path("numberNinja") numberNinja:Int
    ) : com.data.network.model.ninja.Ninja


}