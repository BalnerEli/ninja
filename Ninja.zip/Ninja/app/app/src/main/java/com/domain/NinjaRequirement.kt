package com.domain

import com.data.NinjaRepository
import com.data.network.model.ninja.Ninja


class NinjaRequirement {
    private val repository = NinjaRepository()

    suspend operator fun invoke(
        numberNinja:Int
    ): Ninja? = repository.getNinjaInfo(numberNinja)
}