package com.domain

import com.data.NinjaRepository
import com.data.network.model.NinjaObject


class NinjaListRequirement {

    private val repository = NinjaRepository()

    suspend operator fun invoke(
        domain:String
    ): NinjaObject? = repository.getDNSInfo(domain)
}