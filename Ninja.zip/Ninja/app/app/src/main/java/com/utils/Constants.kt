package com.utils

object Constants {
    const val BASE_URL = "https://api.api-ninjas.com/v1/"
    const val SPLASHCREEN_DURATION = 3000L
    const val MENU_NINJA = "NINJA"
    const val URL_NINJA = "URL_NINJA"
}