package com.framework.views.activities

import android.app.Activity
import android.os.Bundle
import android.util.Log
import com.example.kotlin.ninja.databinding.ActivityNinjaDetailBinding
import com.utils.Constants

class NinjaDetailActivity: Activity() {
    private lateinit var binding: ActivityNinjaDetailBinding
    private var ninjaUrl:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        manageIntent()
        initializeBinding()
    }

    private fun initializeBinding(){
        binding = ActivityNinjaDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    private fun manageIntent(){
        if(intent != null){
            ninjaUrl = intent.getStringExtra(Constants.URL_NINJA)
            Log.d("Salida",ninjaUrl.toString())
        }
    }
}