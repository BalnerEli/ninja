package com.data.network.model

import com.google.gson.annotations.SerializedName

data class NinjaObject(
    @SerializedName("count") val count: Int,
    @SerializedName("results") val results: ArrayList<com.data.network.model.NinjaBase>,
)
