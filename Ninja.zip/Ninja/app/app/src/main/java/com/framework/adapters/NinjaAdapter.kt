package com.framework.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.framework.adapters.ViewHolders.NinjaViewHolder
import com.example.kotlin.ninjaapp.databinding.ItemNinjaBinding



class NinjaAdapter: RecyclerView.Adapter<NinjaViewHolder>() {
    var data:ArrayList<com.data.network.model.NinjaBase> = ArrayList()
    lateinit var context: Context

    override fun onBindViewHolder(holder: NinjaViewHolder, position: Int) {
        val item = data[position]
        holder.bind(item,context)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NinjaViewHolder {
        val binding = ItemNinjaBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return NinjaViewHolder(binding)
    }
    override fun getItemCount(): Int {
        return data.size
    }
}