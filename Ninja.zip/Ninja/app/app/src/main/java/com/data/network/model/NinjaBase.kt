package com.data.network.model

import com.google.gson.annotations.SerializedName

data class NinjaBase(
    @SerializedName("name") val name: String,
    @SerializedName("url") val url: String,
)