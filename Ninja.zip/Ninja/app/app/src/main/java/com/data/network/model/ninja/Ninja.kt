package com.data.network.model.ninja

data class Ninja(
    val record_type: String,
    val mname: String,
    val rname: String,
    val serial: Int,
    val refresh: Int,
    val retry: Int,
    val expire: Int,
    val ttl: Int,


)