package com.framework.viewmodel

import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel() {


}