package com.data.network
import com.data.network.model.ninja.Ninja


class NinjaApiClient {
    private lateinit var api: NinjaAPIService

    suspend fun getDNSInfo(domain: String): com.data.network.model.NinjaObject?{
        api = NetworkModuleDI()
        return try{
            api.getDNSInfo(domain)
        }catch (e:java.lang.Exception){
            e.printStackTrace()
            null
        }
    }

    suspend fun getNinjaInfo(numberNinja:Int): Ninja? {
        api = NetworkModuleDI()
        return try{
            api.getNinjaInfo(numberNinja)
        }catch (e:java.lang.Exception){
            e.printStackTrace()
            null
        }
    }
}